package com.example.stockwidget;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import java.util.ArrayList;
import java.util.Date;

public class MyFactory implements RemoteViewsService.RemoteViewsFactory {

    ArrayList<String> key;
    ArrayList<String> value;
    Context context;
    //SimpleDateFormat sdf;
    int widgetID;

    MyFactory(Context ctx, Intent intent) {
        context = ctx;
     //   sdf = new SimpleDateFormat("HH:mm:ss");
        widgetID = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);
        key =new ArrayList<String>();
        value = new ArrayList<String>();
        key = intent.getStringArrayListExtra("key");
        value = intent.getStringArrayListExtra("value");

    }

    @Override
    public void onCreate() {
     //   data = new ArrayList<String>();
    }

    @Override
    public int getCount() {
        return key.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public RemoteViews getViewAt(int position) {
        RemoteViews rView = new RemoteViews(context.getPackageName(),
                R.layout.item);
        rView.setTextViewText(R.id.tvItemText, key.get(position) + " " + value.get(position));
        return rView;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public void onDataSetChanged() {
        key.clear();
        value.clear();
       // key = intent.getStringArrayListExtra("key");
      //  value = intent.getStringArrayListExtra("value")
      //  data.add(sdf.format(new Date(System.currentTimeMillis())));
       // data./add(String.valueOf(hashCode()));
      //  data.add(String.valueOf(widgetID));
     //   for (int i = 3; i < 15; i++) {
     //       data.add("Item " + i);
       // }
    }

    @Override
    public void onDestroy() {

    }

}
