package com.example.stockwidget

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.PersistableBundle
import android.util.Log
import android.widget.LinearLayout
import android.widget.LinearLayout.LayoutParams
import android.widget.RemoteViews
import android.widget.TextView
import com.example.stockwidget.CreateJob.WidgetJobServise
import com.example.stockwidget.retrofit.Portfolio
import com.example.stockwidget.retrofit.restInterFace
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Response
import java.util.concurrent.TimeUnit
import javax.security.auth.callback.Callback

/**
 * Implementation of App Widget functionality.
 * App Widget Configuration implemented in [NewAppWidgetConfigureActivity]
 */
class NewAppWidget : AppWidgetProvider() {
    var arrayKey: Array<String> = emptyArray()
    var arrayValue : Array<String> = emptyArray()
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {

        // There may be multiple widgets active, so update all of them
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        // When the user deletes the widget, delete the preference associated with it.
        for (appWidgetId in appWidgetIds) {
            deleteTitlePref(context, appWidgetId)
        }
    }

    override fun onEnabled(context: Context) {
        //var key :String
        //var value:String
        val idClient = loadTitlePref(context, PREF_PREFIX_KEY)
        val exceptionCoroutine =
            CoroutineExceptionHandler {_, exception ->
                arrayKey = emptyArray()
                arrayValue = emptyArray()
                arrayKey.plus(" Error")
                arrayValue.plus(exception.toString())
        }
        GlobalScope.launch(Dispatchers.IO + exceptionCoroutine) {
            val resp = restInterFace().getFastPortFolio(idClient)
            var pos = resp.positions
                for ( stock in pos){
                    Log.d("mystock1", stock.toString() )
           //       key =   stock.securityCode.toString()
              //    value =   stock.currentPrice.toString()
                   // arrayKey.plus(key.toString())
                   // arrayValue.plus(value.toString())
                    withContext(Dispatchers.Main){
                        arrayKey.plus(stock.securityCode.toString())
                        arrayValue.plus(stock.currentPrice.toString())
                    }
                }

                }

       //первый запуск job Shedule
        val extraInf = PersistableBundle()

        extraInf.putString("id", idClient)
        //uncial number job ID
        val sJobID = 1
        val componentName = ComponentName(context, WidgetJobServise::class.java)
        val jobInfo = JobInfo.Builder(sJobID, componentName)
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            // setting interval update
            .setOverrideDeadline(TimeUnit.MINUTES.toMillis(1))
            .setPersisted(true)
            .setExtras(extraInf)
            .build()

        val jobScheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        jobScheduler.schedule(jobInfo)


//конец первого запуска

            // Enter relevant functionality for when the first widget is created

    }

    override fun onDisabled(context: Context) {
        // Enter relevant functionality for when the last widget is disabled
    }

    override fun onReceive(context: Context?, intent: Intent?) {
        if(intent?.action == AppWidgetManager.ACTION_APPWIDGET_UPDATE){
            //val shadowKey
            arrayKey = intent?.getStringArrayExtra("key") as Array<String>
            arrayValue = intent?.getStringArrayExtra("value") as Array<String>
            context?.let { onUpdate(it, intent) }

        } else {
            super.onReceive(context, intent)
        }


        }
    fun onUpdate(context: Context, intent: Intent?){

        val idClient = loadTitlePref(context, PREF_PREFIX_KEY)
        val extraInf = PersistableBundle()

        extraInf.putString("id", idClient)
        //uncial number job ID
        val sJobID = 1
        val componentName = ComponentName(context, WidgetJobServise::class.java)
        val jobInfo = JobInfo.Builder(sJobID, componentName)
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            // setting interval update
            .setOverrideDeadline(TimeUnit.MINUTES.toMillis(1))
            .setPersisted(true)
            .setExtras(extraInf)
            .build()

        val jobScheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        jobScheduler.schedule(jobInfo)

        val appWidgetManager: AppWidgetManager = AppWidgetManager.getInstance(context)
        val newComponentName: ComponentName = ComponentName(context, NewAppWidget::class.java)
        val appWidgetId =  appWidgetManager.getAppWidgetIds(newComponentName)

        onUpdate(context, appWidgetManager, appWidgetId)


    }
    internal  fun updateAppWidget(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int
    ) {


        //Нужно загрузить данные из ретрофита
        val widgetText = loadTitlePref(context, appWidgetId.toString())
        // Construct the RemoteViews object
        // Нужно вруную сконструировать layout
        //  val layoutWidget = LinearLayout(context)
        //   layoutWidget.orientation = LinearLayout.VERTICAL
        //  layoutWidget.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)

        //мы должны в цикле добавлять название акций цену и позиуию и изменение цены в лайоут
        // var counter = 0
        // for(key in   arrayKey){
        //        val text = TextView(context,)
        //      text.setText("$key   ${arrayValue[counter]}")
        //    counter += 1
        //    val layoutWidgetVertical = LinearLayout(context)
        //    layoutWidgetVertical.orientation = LinearLayout.HORIZONTAL
        //    layoutWidgetVertical.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        //    layoutWidgetVertical.addView(text)
        //   layoutWidget.addView(layoutWidgetVertical)
        //}

        //
        val views = RemoteViews(context.packageName, R.layout.new_app_widget)
        //  setUpdate(views, context , appWidgetId)
        setList(views, context, appWidgetId)
        //setListClick

        //   views.setTextViewText(R.id.appwidget_text, widgetText)

        // Instruct the widget manager to update the widget
        appWidgetManager.updateAppWidget(appWidgetId, views)
    }

    private fun setList(views: RemoteViews, context: Context, appWidgetId: Int) {
        var adapter = Intent(context, MyService::class.java)
        adapter.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        adapter.putExtra("key", arrayKey)
        adapter.putExtra("value", arrayValue)
        views.setRemoteAdapter(R.id.lvList, adapter)
    }

    }



   // private fun setUpdate(views: RemoteViews, context: Context, appWidgetId: Int) {
   //     var updIntent = Intent(context, NewAppWidget::class.java)
   //     updIntent.action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
   //     updIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, Array())

    //}



