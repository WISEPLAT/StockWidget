
package com.example.stockwidget.retrofit;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Content {

    @SerializedName("includeCurrencies")
    @Expose
    private Boolean includeCurrencies;
    @SerializedName("includeMoney")
    @Expose
    private Boolean includeMoney;
    @SerializedName("includePositions")
    @Expose
    private Boolean includePositions;
    @SerializedName("includeMaxBuySell")
    @Expose
    private Boolean includeMaxBuySell;

    public Boolean getIncludeCurrencies() {
        return includeCurrencies;
    }

    public void setIncludeCurrencies(Boolean includeCurrencies) {
        this.includeCurrencies = includeCurrencies;
    }

    public Boolean getIncludeMoney() {
        return includeMoney;
    }

    public void setIncludeMoney(Boolean includeMoney) {
        this.includeMoney = includeMoney;
    }

    public Boolean getIncludePositions() {
        return includePositions;
    }

    public void setIncludePositions(Boolean includePositions) {
        this.includePositions = includePositions;
    }

    public Boolean getIncludeMaxBuySell() {
        return includeMaxBuySell;
    }

    public void setIncludeMaxBuySell(Boolean includeMaxBuySell) {
        this.includeMaxBuySell = includeMaxBuySell;
    }

}
