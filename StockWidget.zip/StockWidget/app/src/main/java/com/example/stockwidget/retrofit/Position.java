
package com.example.stockwidget.retrofit;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Position {

    @SerializedName("securityCode")
    @Expose
    private String securityCode;
    @SerializedName("market")
    @Expose
    private String market;
    @SerializedName("balance")
    @Expose
    private Integer balance;
    @SerializedName("currentPrice")
    @Expose
    private Integer currentPrice;
    @SerializedName("equity")
    @Expose
    private Integer equity;
    @SerializedName("averagePrice")
    @Expose
    private Integer averagePrice;
    @SerializedName("currency")
    @Expose
    private String currency;
    @SerializedName("accumulatedProfit")
    @Expose
    private Integer accumulatedProfit;
    @SerializedName("todayProfit")
    @Expose
    private Integer todayProfit;
    @SerializedName("unrealizedProfit")
    @Expose
    private Integer unrealizedProfit;
    @SerializedName("profit")
    @Expose
    private Integer profit;
    @SerializedName("maxBuy")
    @Expose
    private Integer maxBuy;
    @SerializedName("maxSell")
    @Expose
    private Integer maxSell;
    @SerializedName("priceCurrency")
    @Expose
    private String priceCurrency;
    @SerializedName("averagePriceCurrency")
    @Expose
    private String averagePriceCurrency;
    @SerializedName("averageRate")
    @Expose
    private Integer averageRate;

    public String getSecurityCode() {
        return securityCode;
    }

    public void setSecurityCode(String securityCode) {
        this.securityCode = securityCode;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    public Integer getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(Integer currentPrice) {
        this.currentPrice = currentPrice;
    }

    public Integer getEquity() {
        return equity;
    }

    public void setEquity(Integer equity) {
        this.equity = equity;
    }

    public Integer getAveragePrice() {
        return averagePrice;
    }

    public void setAveragePrice(Integer averagePrice) {
        this.averagePrice = averagePrice;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Integer getAccumulatedProfit() {
        return accumulatedProfit;
    }

    public void setAccumulatedProfit(Integer accumulatedProfit) {
        this.accumulatedProfit = accumulatedProfit;
    }

    public Integer getTodayProfit() {
        return todayProfit;
    }

    public void setTodayProfit(Integer todayProfit) {
        this.todayProfit = todayProfit;
    }

    public Integer getUnrealizedProfit() {
        return unrealizedProfit;
    }

    public void setUnrealizedProfit(Integer unrealizedProfit) {
        this.unrealizedProfit = unrealizedProfit;
    }

    public Integer getProfit() {
        return profit;
    }

    public void setProfit(Integer profit) {
        this.profit = profit;
    }

    public Integer getMaxBuy() {
        return maxBuy;
    }

    public void setMaxBuy(Integer maxBuy) {
        this.maxBuy = maxBuy;
    }

    public Integer getMaxSell() {
        return maxSell;
    }

    public void setMaxSell(Integer maxSell) {
        this.maxSell = maxSell;
    }

    public String getPriceCurrency() {
        return priceCurrency;
    }

    public void setPriceCurrency(String priceCurrency) {
        this.priceCurrency = priceCurrency;
    }

    public String getAveragePriceCurrency() {
        return averagePriceCurrency;
    }

    public void setAveragePriceCurrency(String averagePriceCurrency) {
        this.averagePriceCurrency = averagePriceCurrency;
    }

    public Integer getAverageRate() {
        return averageRate;
    }

    public void setAverageRate(Integer averageRate) {
        this.averageRate = averageRate;
    }

}
