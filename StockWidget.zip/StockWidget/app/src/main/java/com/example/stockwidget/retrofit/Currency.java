
package com.example.stockwidget.retrofit;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Currency {

    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("balance")
    @Expose
    private Integer balance;
    @SerializedName("crossRate")
    @Expose
    private Integer crossRate;
    @SerializedName("equity")
    @Expose
    private Integer equity;
    @SerializedName("unrealizedProfit")
    @Expose
    private Integer unrealizedProfit;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    public Integer getCrossRate() {
        return crossRate;
    }

    public void setCrossRate(Integer crossRate) {
        this.crossRate = crossRate;
    }

    public Integer getEquity() {
        return equity;
    }

    public void setEquity(Integer equity) {
        this.equity = equity;
    }

    public Integer getUnrealizedProfit() {
        return unrealizedProfit;
    }

    public void setUnrealizedProfit(Integer unrealizedProfit) {
        this.unrealizedProfit = unrealizedProfit;
    }

}
