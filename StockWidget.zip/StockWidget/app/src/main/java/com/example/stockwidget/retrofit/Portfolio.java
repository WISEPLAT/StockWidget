
package com.example.stockwidget.retrofit;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Portfolio {

    @SerializedName("clientId")
    @Expose
    private String clientId;
    @SerializedName("content")
    @Expose
    private Content content;
    @SerializedName("equity")
    @Expose
    private Integer equity;
    @SerializedName("balance")
    @Expose
    private Integer balance;
    @SerializedName("positions")
    @Expose
    private List<Position> positions;
    @SerializedName("currencies")
    @Expose
    private List<Currency> currencies;
    @SerializedName("money")
    @Expose
    private List<Money> money;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public Content getContent() {
        return content;
    }

    public void setContent(Content content) {
        this.content = content;
    }

    public Integer getEquity() {
        return equity;
    }

    public void setEquity(Integer equity) {
        this.equity = equity;
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    public List<Position> getPositions() {
        return positions;
    }

    public void setPositions(List<Position> positions) {
        this.positions = positions;
    }

    public List<Currency> getCurrencies() {
        return currencies;
    }

    public void setCurrencies(List<Currency> currencies) {
        this.currencies = currencies;
    }

    public List<Money> getMoney() {
        return money;
    }

    public void setMoney(List<Money> money) {
        this.money = money;
    }

}
