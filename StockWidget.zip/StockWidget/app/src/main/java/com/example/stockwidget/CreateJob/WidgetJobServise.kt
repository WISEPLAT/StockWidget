package com.example.stockwidget.CreateJob

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.PersistableBundle
import android.util.Log
import androidx.work.Configuration
import com.example.stockwidget.NewAppWidget
import com.example.stockwidget.PREF_PREFIX_KEY
import com.example.stockwidget.loadTitlePref
import com.example.stockwidget.retrofit.Portfolio
import com.example.stockwidget.retrofit.restInterFace
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.concurrent.TimeUnit

class WidgetJobServise : JobService() {
    init {
        Configuration.Builder().setJobSchedulerJobIdRange(0, 1000).build()
    }


    override fun onStartJob(p0: JobParameters?): Boolean {
        val clientId =   p0?.extras?.getString("id") ?: "00000000"
        var arrayKey: Array<String> = emptyArray()
        var arrayValue : Array<String> = emptyArray()
     //  CoroutineScope(Dispatchers.IO).launch {

         //  val  exchange: MutableMap<String, String> = mutableMapOf()
         //  val arrayKey: Array<String> = emptyArray()
        //   val arrayValue : Array<String> = emptyArray()

        //   Log.d("ClientId", clientId)
     //   val resp : Call<Portfolio> = restInterFace().getPortfolio(clientId = clientId)

       //    resp.enqueue(object : Callback<Portfolio> {
     //          override fun onFailure(call: Call<Portfolio>, t: Throwable) {
     //              TODO("Not yet implemented")
     //          }

     //          override fun onResponse(call: Call<Portfolio>, response: Response<Portfolio>) {
      //            if (response.code() == 400){
       ///            val positions =  response.body()?.positions
       //               for (stock in positions!!){
       //                  val key = stock.securityCode
         //                 val value = stock.priceCurrency
                          //exchange.put(key, value)
        //                  arrayKey.plus(key)
       //                   arrayValue.plus(value)
        //              }
      //            }else{
                      //Error
     //             }

      //         }
     //      })

           val exceptionCoroutine =
               CoroutineExceptionHandler {_, exception ->
                 var  arrayKey : Array<String>  = emptyArray();
                 var  arrayValue:  Array<String> = emptyArray();
                   arrayKey.plus(" Error")
                   arrayValue.plus(exception.toString())

                   val idClient = loadTitlePref(applicationContext, PREF_PREFIX_KEY)
                   val extraInf = PersistableBundle()

                   extraInf.putString("id", idClient)
                   //uncial number job ID
                   val sJobID = 1
                   val componentName = ComponentName(applicationContext, WidgetJobServise::class.java)
                   val jobInfo = JobInfo.Builder(sJobID, componentName)
                       .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                       // setting interval update
                       .setOverrideDeadline(TimeUnit.MINUTES.toMillis(1))
                       .setPersisted(true)
                       .setExtras(extraInf)
                       .build()

                   val jobScheduler = applicationContext.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
                   jobScheduler.schedule(jobInfo)
                   val forceWidgetUpdate = Intent(applicationContext, NewAppWidget::class.java)
                   forceWidgetUpdate.action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                   forceWidgetUpdate.putExtra("key", arrayKey)
                   forceWidgetUpdate.putExtra("value", arrayValue)
                   sendBroadcast(forceWidgetUpdate)


                   jobFinished(p0, false)
               }
           GlobalScope.launch(Dispatchers.IO + exceptionCoroutine) {
               var  arrayKey : Array<String>  = emptyArray();
               var  arrayValue:  Array<String> = emptyArray();
               val resp = restInterFace().getFastPortFolio(clientId)
               var pos = resp.positions
               for ( stock in pos){
                   val key =   stock.securityCode
                   val value =   stock.currentPrice
                   arrayKey.plus(key)
                   arrayValue.plus(value.toString())
               }
               val idClient = loadTitlePref(applicationContext, PREF_PREFIX_KEY)
               val extraInf = PersistableBundle()

               extraInf.putString("id", idClient)
               //uncial number job ID
               val sJobID = 1
               val componentName = ComponentName(applicationContext, WidgetJobServise::class.java)
               val jobInfo = JobInfo.Builder(sJobID, componentName)
                   .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                   // setting interval update
                   .setOverrideDeadline(TimeUnit.MINUTES.toMillis(1))
                   .setPersisted(true)
                   .setExtras(extraInf)
                   .build()

               val jobScheduler = applicationContext.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
               jobScheduler.schedule(jobInfo)
               val forceWidgetUpdate = Intent(applicationContext, NewAppWidget::class.java)
               forceWidgetUpdate.action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
               forceWidgetUpdate.putExtra("key", arrayKey)
               forceWidgetUpdate.putExtra("value", arrayValue)
               sendBroadcast(forceWidgetUpdate)

               jobFinished(p0, false)

           }

           //





        return true
    }

    override fun onStopJob(p0: JobParameters?): Boolean {
        return true
    }

}