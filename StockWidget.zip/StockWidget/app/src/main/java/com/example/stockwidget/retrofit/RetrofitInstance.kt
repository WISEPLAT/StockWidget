package com.example.stockwidget.retrofit

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create


fun getRetrofit(): Retrofit {
        return Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl("https://trade-api.comon.ru")
            .build()
    }

fun restInterFace(): RetrofitInterfase{
   return getRetrofit().create(RetrofitInterfase::class.java)
}