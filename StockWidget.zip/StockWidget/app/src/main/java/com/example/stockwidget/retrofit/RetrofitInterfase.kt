package com.example.stockwidget.retrofit

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface RetrofitInterfase {

    @Headers(
        "Authorization:  CAEQ0cUBGhhYoXc5yBHiWNenrpniF3QQ5hSWMVdEUP8="
    )
    @GET("/api/v1/portfolio/?includeCurrencies=true&includeMoney=true&includePositions=true&includeMaxBuySell=true")
 suspend  fun getPortfolio(@Query("clientId") clientId: String) : Call<Portfolio>
 suspend fun getFastPortFolio(@Query("clientId") clientId: String) : Portfolio
}